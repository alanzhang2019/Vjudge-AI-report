#!/bin/bash
echo "=== 82506e46 报告中 CSP/level 关键词 ==="
grep -nE '当前对应|当前等级|核心等级|CSP-J|CSP-S|定级|真实水平' /home/ubuntu/luogu-ai-report/reports/82506e46_周子蓝/report_noi_csp.md 2>/dev/null | head -20
echo
echo "=== 82506e46 第 5 节上下文 ==="
awk '/## 5\./,/## 6\./' /home/ubuntu/luogu-ai-report/reports/82506e46_周子蓝/report_noi_csp.md 2>/dev/null | head -30
