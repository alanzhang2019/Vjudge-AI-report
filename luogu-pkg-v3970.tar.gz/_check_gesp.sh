#!/bin/bash
echo "=== 7a5bb4ad 报告目录与文件 ==="
ls -la /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林绍涵/ 2>&1
echo
echo "=== report_gesp.md 前 60 行 ==="
head -60 /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林绍涵/report_gesp.md 2>&1
echo
echo "=== 7e489383 报告目录与文件 ==="
ls -la /home/ubuntu/luogu-ai-report/reports/7e489383_朵云熙/ 2>&1
echo
echo "=== report_gesp.md 前 60 行 ==="
head -60 /home/ubuntu/luogu-ai-report/reports/7e489383_朵云熙/report_gesp.md 2>&1
