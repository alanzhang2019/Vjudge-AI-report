#!/bin/bash
echo "=== 570175 目录 ==="
sudo find /home/ubuntu/luogu-ai-report/reports -maxdepth 2 -name "*570175*" -type d
echo
echo "=== 570175 文件 ==="
DIR=$(sudo find /home/ubuntu/luogu-ai-report/reports -maxdepth 2 -name "*570175*" -type d | head -1)
ls -la "$DIR/" 2>/dev/null
echo
echo "=== 570175 所有 GESP/CSP 等级关键词 ==="
grep -nE 'GESP\s*[0-9]+|CSP-[JS]|AI\s*评级|AI\s*定级|目标级别|学员当前实力|已通过最高' "$DIR/report_gesp.md" 2>/dev/null | head -20
echo
echo "=== 570175 第 0-3 节 ==="
grep -nE '^#' "$DIR/report_gesp.md" 2>/dev/null | head -20
