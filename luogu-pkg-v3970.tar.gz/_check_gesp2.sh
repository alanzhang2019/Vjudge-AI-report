#!/bin/bash
echo "=== 查找 7a5bb4ad 和 7e489383 ==="
find /home/ubuntu/luogu-ai-report -type d -name "*7a5bb4ad*" 2>/dev/null
find /home/ubuntu/luogu-ai-report -type d -name "*7e489383*" 2>/dev/null
echo
echo "=== tasks.db 中查询 ==="
sudo docker exec luogu-ai-report-luogu-coach python -c "
import sqlite3
con = sqlite3.connect('/app/data/tasks.db')
for uid in ['7a5bb4ad', '7e489383']:
    print(f'--- {uid} ---')
    cur = con.execute('SELECT luogu_uid, real_name, report_type, status, report_dir FROM tasks WHERE luogu_uid=?', (uid,))
    for r in cur.fetchall():
        print(r)
" 2>&1
