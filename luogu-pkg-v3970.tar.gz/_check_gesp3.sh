#!/bin/bash
echo "=== 7a5bb4ad 实际目录 ==="
ls -la /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/ 2>&1
echo
echo "=== report_gesp.md 前 80 行（如果存在）==="
head -80 /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>&1
echo
echo "=== 7e489383 实际目录 ==="
ls -la /home/ubuntu/luogu-ai-report/reports/7e489383_边云舒/ 2>&1
echo
echo "=== report_gesp.md 前 80 行 ==="
head -80 /home/ubuntu/luogu-ai-report/reports/7e489383_边云舒/report_gesp.md 2>&1
