#!/bin/bash
echo "=== 7a5bb4ad_林珅熠 报告中 GESP 关键词 ==="
grep -nE '目标级别|GESP [0-9]|AI.*定级|AI.*评级|真实水平|定级结论|当前对应等级' /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>/dev/null | head -20
echo
echo "=== 7e489383_边云舒 报告中 GESP 关键词 ==="
grep -nE '目标级别|GESP [0-9]|AI.*定级|AI.*评级|真实水平|定级结论|当前对应等级' /home/ubuntu/luogu-ai-report/reports/7e489383_边云舒/report_gesp.md 2>/dev/null | head -20
echo
echo "=== 7a5bb4ad 报告前 30 行（找目标级别）==="
head -30 /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>/dev/null
