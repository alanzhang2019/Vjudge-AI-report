#!/bin/bash
echo "=== 7a5bb4ad 报告前 10 行 ==="
head -10 /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>&1
echo
echo "=== 7a5bb4ad 文件名 ==="
ls /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/ 2>&1
echo
echo "=== 7e489383 报告前 10 行 ==="
head -10 /home/ubuntu/luogu-ai-report/reports/7e489383_边云舒/report_gesp.md 2>&1
echo
echo "=== 7e489383 文件名 ==="
ls /home/ubuntu/luogu-ai-report/reports/7e489383_边云舒/ 2>&1
