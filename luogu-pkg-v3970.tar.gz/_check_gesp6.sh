#!/bin/bash
echo "=== 7a5bb4ad 报告中所有 GESP 关键词 ==="
grep -nE 'GESP|目标级别|定级' /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>/dev/null | head -30
echo
echo "=== 7a5bb4ad 报告中 第 1-3 节 ==="
grep -nE '^##|^###' /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>/dev/null | head -30
