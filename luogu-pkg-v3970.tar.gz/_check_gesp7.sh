#!/bin/bash
echo "=== 7a5bb4ad 学员当前实力 上下文 ==="
grep -A 2 "学员当前实力" /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>/dev/null
echo
echo "=== 7e489383 学员当前实力 上下文 ==="
grep -A 2 "学员当前实力" /home/ubuntu/luogu-ai-report/reports/7e489383_边云舒/report_gesp.md 2>/dev/null
echo
echo "=== 7a5bb4ad 所有 GESP 数字级别 ==="
grep -oE 'GESP\s*[0-9]+\s*级[^\n]{0,30}' /home/ubuntu/luogu-ai-report/reports/7a5bb4ad_林珅熠/report_gesp.md 2>/dev/null | head -10
echo
echo "=== 7e489383 所有 GESP 数字级别 ==="
grep -oE 'GESP\s*[0-9]+\s*级[^\n]{0,30}' /home/ubuntu/luogu-ai-report/reports/7e489383_边云舒/report_gesp.md 2>/dev/null | head -10
