#!/bin/bash
echo "=== 7e489383 文件列表 ==="
ls -la /home/ubuntu/luogu-ai-report/reports/ | grep -i "7e489383"
echo
echo "=== 7e489383 可能的目录名 ==="
sudo find /home/ubuntu/luogu-ai-report/reports -maxdepth 2 -name "*7e489383*" -type d
echo
echo "=== 7e489383 报告前 50 行 ==="
DIR=$(sudo find /home/ubuntu/luogu-ai-report/reports -maxdepth 2 -name "*7e489383*" -type d | head -1)
echo "DIR=$DIR"
[ -n "$DIR" ] && head -50 "$DIR/report_gesp.md"
