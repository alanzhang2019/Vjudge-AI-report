#!/bin/bash
DIR=$(sudo find /home/ubuntu/luogu-ai-report/reports -maxdepth 2 -name "*7e489383*" -type d | head -1)
echo "DIR=$DIR"
echo
echo "=== 学员当前实力附近 ==="
grep -B 1 -A 1 "学员当前实力" "$DIR/report_gesp.md" 2>/dev/null
echo
echo "=== 所有 GESP 数字级别 ==="
grep -nE 'GESP\s*[0-9]+\s*级' "$DIR/report_gesp.md" 2>/dev/null | head -20
echo
echo "=== 目标级别附近 ==="
grep -B 1 -A 1 "目标级别" "$DIR/report_gesp.md" 2>/dev/null
