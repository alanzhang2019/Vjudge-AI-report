#!/bin/bash
sudo docker exec luogu-ai-report-luogu-coach python -c "
import re
with open('/app/reports/7a5bb4ad_林珅熠/report_gesp.md', 'r', encoding='utf-8') as f:
    text = f.read()
print('--- 学员当前实力 patterns ---')
for pat in [
    r'目标级别[：:]\s*\*\*\s*(GESP\s*\d+\s*级)\s*\*\*',
    r'学员当前实力[：:]\s*\*?\*?\s*((?:GESP\s*\d+\s*级)[^*\n]{0,30}?)\*?\*?',
    r'(GESP\s*\d+\s*级)',
    r'学员当前实力.{0,30}',
]:
    m = re.search(pat, text)
    if m:
        g = list(m.groups())
        val = g[0] if g else m.group(0)
        print(f'  HIT: {pat[:35]}...')
        print(f'    val: {val!r}')
    else:
        print(f'  MISS: {pat[:35]}...')
"
