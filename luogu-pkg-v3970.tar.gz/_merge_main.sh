#!/bin/bash
set -e
cd /home/ubuntu/luogu-ai-report

echo "=== current state ==="
git branch -v
echo "---"

echo "=== fetch all ==="
git fetch --all 2>&1 | grep -v "From github.com" | head -5

echo "=== checkout main ==="
git checkout main 2>&1

echo "=== merge v3.5.2-commercial into main ==="
git merge v3.5.2-commercial --no-edit 2>&1

echo "=== push main to origin ==="
git push origin main 2>&1

echo "=== done ==="
git log --oneline -3
