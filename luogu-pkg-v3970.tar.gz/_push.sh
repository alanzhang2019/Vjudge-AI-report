#!/bin/bash
set -e
git config --global url."git@github.com:".insteadOf "https://github.com/"
echo "rewrite ok"
cd /home/ubuntu/luogu-ai-report
git remote -v
echo "---push origin---"
git push origin v3.5.2-commercial 2>&1
