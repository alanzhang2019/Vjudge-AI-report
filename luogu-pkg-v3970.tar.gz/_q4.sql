.schema students
