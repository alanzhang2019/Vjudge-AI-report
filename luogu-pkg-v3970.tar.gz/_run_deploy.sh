#!/bin/bash
cd /home/ubuntu/luogu-ai-report
cp /tmp/luogu-ai-report-pkg.tar.gz ./luogu-ai-report-pkg.tar.gz
nohup bash ./deploy.sh --from-zip > /tmp/deploy_v5.log 2>&1 &
echo "DEPLOY_PID=$!"
sleep 2
tail -5 /tmp/deploy_v5.log 2>&1
