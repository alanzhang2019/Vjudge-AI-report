#!/bin/bash
sudo docker exec luogu-ai-report-luogu-coach python << 'PYEOF'
import sys; sys.path.insert(0, '/app')
import os; os.chdir('/app')
from web_app import _build_share_card_data
for uid in ['11f45164', '7a5bb4ad', '7e489383']:
    d = _build_share_card_data(uid, exam_type='gesp')
    if d:
        print(f'{uid} NAME:', d.get('name'))
        print(f'{uid} AI_LEVEL:', repr(d.get('ai_level')))
    else:
        print(f'{uid}: NO DATA')
PYEOF
