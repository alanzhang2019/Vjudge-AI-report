#!/bin/bash
for uid in 85bc1cb3 8abdcb7c 82506e46 81d3f2e4 fde34c1e 7809cd5a 7a5bb4ad 7e489383; do
  ext="noi_csp"
  if [[ "$uid" == "7a5bb4ad" || "$uid" == "7e489383" ]]; then ext="gesp"; fi
  printf "%s (exam=%s): " "$uid" "$ext"
  curl -s -o /tmp/test_$uid.png -w "status=%{http_code} size=%{size_download}\n" "http://127.0.0.1:5000/me/$uid/share-card.png?exam_type=$ext"
done
