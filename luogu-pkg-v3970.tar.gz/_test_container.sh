#!/bin/bash
echo "=== AI 定级提取结果 (新代码) ==="
for case in "85bc1cb3:noi_csp" "8abdcb7c:noi_csp" "82506e46:noi_csp" "81d3f2e4:noi_csp" "fde34c1e:noi_csp" "7809cd5a:noi_csp" "7a5bb4ad:gesp" "7e489383:gesp"; do
  uid="${case%%:*}"
  et="${case##*:}"
  out=$(sudo docker exec luogu-ai-report-luogu-coach python -c "
import sys; sys.path.insert(0, '/app')
import os
os.chdir('/app')
from web_app import _build_share_card_data
d = _build_share_card_data('$uid', exam_type='$et')
if d:
    print('NAME:', d.get('name'))
    print('AI_LEVEL:', repr(d.get('ai_level')))
    print('EXAM_TYPE:', d.get('exam_type'))
else:
    print('NO DATA')
" 2>&1)
  echo "--- $uid ($et) ---"
  echo "$out"
  echo
done
