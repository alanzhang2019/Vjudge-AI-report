Set-Location "C:\Users\zpy20\Desktop\项目\luoguAI\luogu-api-python"
$env:GIT_PAGER = "cat"
$logPath = "C:\Users\zpy20\Desktop\gitlog.txt"
"=== git diff name-only ===" | Out-File -FilePath $logPath -Encoding utf8
git --no-pager diff --name-only HEAD 2>&1 | Out-File -FilePath $logPath -Encoding utf8 -Append
"=== git log -1 ===" | Out-File -FilePath $logPath -Encoding utf8 -Append
git --no-pager log -1 --pretty=format:"%H %s" 2>&1 | Out-File -FilePath $logPath -Encoding utf8 -Append
"" | Out-File -FilePath $logPath -Encoding utf8 -Append
"=== pwd ===" | Out-File -FilePath $logPath -Encoding utf8 -Append
Get-Location | Out-File -FilePath $logPath -Encoding utf8 -Append
"=== done ===" | Out-File -FilePath $logPath -Encoding utf8 -Append