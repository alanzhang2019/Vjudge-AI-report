Set-Location "C:\Users\zpy20\Desktop\项目\luoguAI\luogu-api-python"
$env:GIT_PAGER = "cat"
# 先 add
git --no-pager add web_app.py 2>&1 | Tee-Object -FilePath "add.log"
# 看 status
git --no-pager status --porcelain 2>&1 | Tee-Object -FilePath "status.log" -Append
# commit
git --no-pager commit -m "fix(web): 修复缓存tag_by_id key类型bug + 修复报告生成时间时区 + 默认抓取全部题目(上限3000)" 2>&1 | Tee-Object -FilePath "commit.log" -Append
"" | Out-File -FilePath "commit.log" -Append
"=== HEAD ===" | Out-File -FilePath "commit.log" -Encoding utf8 -Append
git --no-pager log -1 --pretty=format:'%H %s' 2>&1 | Out-File -FilePath "commit.log" -Encoding utf8 -Append
"=== END ===" | Out-File -FilePath "commit.log" -Encoding utf8 -Append