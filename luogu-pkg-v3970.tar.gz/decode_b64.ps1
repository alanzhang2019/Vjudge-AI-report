# Decode report.md from base64 to a local file
$srcB64 = "C:\Users\zpy20\Desktop\项目\luoguAI\luogu-api-python\report_md.b64"
$dstMd  = "C:\Users\zpy20\Desktop\项目\luoguAI\luogu-api-python\report_md_latest.txt"

if (-not (Test-Path $srcB64)) { Write-Host "Source not found: $srcB64"; exit 1 }
$b64 = Get-Content $srcB64 -Raw
if ([string]::IsNullOrWhiteSpace($b64)) { Write-Host "Source is empty"; exit 1 }
$b64 = $b64.Trim()
$bytes = [System.Convert]::FromBase64String($b64)
$text  = [System.Text.Encoding]::UTF8.GetString($bytes)
[System.IO.File]::WriteAllText($dstMd, $text, [System.Text.Encoding]::UTF8)
Write-Host ("Decoded length: {0} chars" -f $text.Length)
