Set-Location "C:\Users\zpy20\Desktop\项目\luoguAI\luogu-api-python"
$env:GIT_PAGER = "cat"
Write-Host "=== git log -3 ==="
git --no-pager log -3 --oneline
Write-Host ""
Write-Host "=== git status ==="
git --no-pager status
Write-Host ""
Write-Host "=== git push ==="
git --no-pager push origin main