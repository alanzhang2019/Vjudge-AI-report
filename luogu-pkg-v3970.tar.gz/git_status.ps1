$env:GIT_PAGER = "cat"
Set-Location "C:\Users\zpy20\Desktop\项目\luoguAI\luogu-api-python"
Write-Host "=== git log ==="
git --no-pager log --oneline -3
Write-Host "=== git status ==="
git --no-pager status --short
Write-Host "=== git diff stat ==="
git --no-pager diff --stat